#!/usr/bin/python3

SPACEMOUSE_TYPE = 'blue'
#SPACEMOUSE_TYPE = 'old'